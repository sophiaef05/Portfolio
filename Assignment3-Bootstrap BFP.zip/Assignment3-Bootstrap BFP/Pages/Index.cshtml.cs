using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Assignment3_Bootstrap_BFP.Pages
{
    public class IndexModel : PageModel
    {
        public class BFPModel
        {
            public string Gender { get; set; }
            public int Age { get; set; }
            public double Weight { get; set; }
            public double Height { get; set; }
            public double Waist { get; set; }
            public double Neck { get; set; }
            public double Hip { get; set; } // Optional for males
            public double BFP { get; set; }
            public string Category { get; set; }
        }

        public void OnGet()
        {

        }
    }
    public class BFPModel : PageModel
    {
        [BindProperty]
        public BFP bfpInput { get; set; }

        public string ResultMessage { get; set; }

        public void OnPost()
        {
            if (bfpInput != null)
            {

                ResultMessage = bfpInput.calculate();

            }
            else
            {
                ResultMessage = "Please fill out all fields.";
            }
        }
    }

    public class BFP
    {
        public string Gender { get; set; }
        public int Age { get; set; }
        public double Weight { get; set; }
        public double Height { get; set; }
        public double BFPValue { get; set; }
        public string Category { get; set; }
        public double BMI { get; set; }

        public string calculate()
        {
            string ResultMessage = "";
            BMI = Math.Round((Weight * 703) / (Height * Height), 2);

            // Calculate BFP based on Gender
            if (Gender.ToLower() == "male")
            {
                BFPValue = 1.20 * BMI + 0.23 * Age - 16.2;
            }
            else if (Gender.ToLower() == "female")
            {
                BFPValue = 1.20 * BMI + 0.23 * Age - 5.4;
            }
            else
            {
                ResultMessage = "Invalid gender. Please choose 'Male' or 'Female'.";
                return ResultMessage;
            }

            // Determine category based on BFP value
            if (Gender.ToLower() == "male")
            {
                Category = BFPValue switch
                {
                    <= 6 => "Essential Fat",
                    <= 24 => "Athletes",
                    <= 31 => "Fitness",
                    <= 39 => "Average",
                    _ => "Obese"
                };
            }
            else
            {
                Category = BFPValue switch
                {
                    <= 14 => "Essential Fat",
                    <= 24 => "Athletes",
                    <= 31 => "Fitness",
                    <= 39 => "Average",
                    _ => "Obese"
                };
            }

            ResultMessage = $"Your Body Fat Percentage (BFP) is {BFPValue:F2}%. You are categorized as {Category}.";
            return ResultMessage;
        }
    }
}

